import Image from "next/image";
import styles from "./page.module.scss";

export default function Home() {
  return (
    <main >
      <h1></h1>
    </main>
  );
}
