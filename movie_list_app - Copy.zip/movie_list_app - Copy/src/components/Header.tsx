import React from 'react'
import styles from "@/styles/components/_container.module.scss"
import Container from './Container'

const Header = () => {
    return (
        <header>
            <Container>
                <p>ádsad</p>
            </Container>
        </header>
    )
}

export default Header